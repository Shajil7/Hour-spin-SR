package com.example.hourlyspinkings

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date
import java.util.UUID

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifications.ensureChannel(this)
        setContent { AppScreen() }
    }

    override fun onResume() {
        super.onResume()
        // Compose screen reads current state on resume.
    }

    private fun accessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val expected = "$packageName/.SpinAccessibilityService"
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) || it.endsWith("/$packageName.SpinAccessibilityService", true) }
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }
    }

    private fun openBatterySettings() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun findAceWinPackages(): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val label = info.loadLabel(packageManager)?.toString() ?: return@mapNotNull null
                if (label.trim().equals("AceWin", ignoreCase = true)) info.activityInfo.packageName to label else null
            }
            .distinctBy { it.first }
    }

    @androidx.compose.runtime.Composable
    private fun AppScreen() {
        var target by remember { mutableStateOf(AppPrefs.targetPackage ?: "Not selected") }
        var enabled by remember { mutableStateOf(AppPrefs.enabled) }
        var testInterval by remember { mutableStateOf(AppPrefs.testIntervalMinutes.toString()) }
        var realInterval by remember { mutableStateOf(AppPrefs.realIntervalMinutes.toString()) }
        var initialDelay by remember { mutableStateOf(AppPrefs.initialDelayMinutes.toString()) }
        var testLogout by remember { mutableStateOf(AppPrefs.testLogout) }
        var showApps by remember { mutableStateOf(false) }
        var refresh by remember { mutableStateOf(0) }

        LaunchedEffect(Unit) {
            while (true) {
                kotlinx.coroutines.delay(1000)
                refresh++
            }
        }

        val access = accessibilityEnabled()
        val exact = Scheduler.canUseExact(this)
        val next = AppPrefs.nextRun.takeIf { it > 0 }?.let { DateFormat.getDateTimeInstance().format(Date(it)) } ?: "Not scheduled"

        Scaffold(topBar = { TopAppBar(title = { Text("Hourly Spin Kings") }) }) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Status", style = MaterialTheme.typography.titleMedium)
                Text(if (enabled) "Automation ON" else "Automation OFF", style = MaterialTheme.typography.headlineSmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Enable automatic schedule")
                    Switch(checked = enabled, onCheckedChange = {
                        enabled = it
                        AppPrefs.enabled = it
                        if (!it) Scheduler.cancel(this@MainActivity)
                    })
                }

                Divider()
                Text("Target app", style = MaterialTheme.typography.titleMedium)
                Text("Selected: $target")
                Button(onClick = { showApps = true }, modifier = Modifier.fillMaxWidth()) { Text("Select AceWin") }

                Text("Required setup", style = MaterialTheme.typography.titleMedium)
                Text(if (access) "Accessibility Service: ON" else "Accessibility Service: OFF")
                OutlinedButton(onClick = { openAccessibilitySettings() }, modifier = Modifier.fillMaxWidth()) { Text("Enable Accessibility") }
                Text(if (exact) "Exact alarms: allowed" else "Exact alarms: not allowed")
                if (!exact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    OutlinedButton(onClick = { openExactAlarmSettings() }, modifier = Modifier.fillMaxWidth()) { Text("Allow Exact Alarms") }
                }
                OutlinedButton(onClick = { requestNotifications() }, modifier = Modifier.fillMaxWidth()) { Text("Allow Notifications") }
                OutlinedButton(onClick = { openBatterySettings() }, modifier = Modifier.fillMaxWidth()) { Text("Battery Optimization Settings") }

                Divider()
                Text("Timing", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(testInterval, { v -> if (v.all(Char::isDigit)) { testInterval = v; v.toIntOrNull()?.let { AppPrefs.testIntervalMinutes = it } } }, label = { Text("Test interval (minutes)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(realInterval, { v -> if (v.all(Char::isDigit)) { realInterval = v; v.toIntOrNull()?.let { AppPrefs.realIntervalMinutes = it } } }, label = { Text("Real interval (minutes, default 65)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(initialDelay, { v -> if (v.all(Char::isDigit)) { initialDelay = v; v.toIntOrNull()?.let { AppPrefs.initialDelayMinutes = it } } }, label = { Text("Initial delay (minutes)") }, modifier = Modifier.fillMaxWidth())

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Test logout step")
                    Checkbox(checked = testLogout, onCheckedChange = { testLogout = it; AppPrefs.testLogout = it })
                }
                Text("Test Now never logs out unless this setting is enabled. It never enters passwords, OTPs, CAPTCHAs, or payment details.", style = MaterialTheme.typography.bodySmall)

                Divider()
                Text("Controls", style = MaterialTheme.typography.titleMedium)
                Button(
                    onClick = {
                        requestNotifications()
                        if (!access) { openAccessibilitySettings(); return@Button }
                        if (AppPrefs.targetPackage.isNullOrBlank()) { showApps = true; return@Button }
                        try {
                            AppPrefs.pendingMode = "TEST"
                            AppPrefs.sessionId = UUID.randomUUID().toString()
                            AppPrefs.cycleStarted = System.currentTimeMillis()
                            AppPrefs.state = "WAKE_REQUESTED"
                            LogStore.add("Test Now requested")
                            ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, AutomationRunnerService::class.java))
                        } catch (e: Exception) {
                            AppPrefs.lastError = e.message ?: "Could not start test"
                        }
                    }, modifier = Modifier.fillMaxWidth()
                ) { Text("Test Now") }
                Button(
                    onClick = {
                        if (!access || AppPrefs.targetPackage.isNullOrBlank()) return@Button
                        requestNotifications()
                        AppPrefs.enabled = true
                        enabled = true
                        try {
                            Scheduler.scheduleAfter(this@MainActivity, AppPrefs.initialDelayMinutes * 60_000L)
                            LogStore.add("automation started")
                        } catch (e: Exception) {
                            AppPrefs.lastError = e.message ?: "Could not schedule"
                        }
                    }, modifier = Modifier.fillMaxWidth()
                ) { Text("Start Automation") }
                OutlinedButton(onClick = { AppPrefs.enabled = false; enabled = false; Scheduler.cancel(this@MainActivity); LogStore.add("automation stopped") }, modifier = Modifier.fillMaxWidth()) { Text("Stop Automation") }

                Divider()
                Text("Current automation state: ${AppPrefs.state}")
                Text("Next run: $next")
                Text("Last run: ${AppPrefs.lastStatus}")
                if (AppPrefs.lastError.isNotBlank()) Text("Error: ${AppPrefs.lastError}")

                Divider()
                Text("Event log", style = MaterialTheme.typography.titleMedium)
                Text(LogStore.all().ifBlank { "No events yet." }, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(30.dp))
            }
        }

        if (showApps) {
            val apps = findAceWinPackages()
            AlertDialog(
                onDismissRequest = { showApps = false },
                title = { Text("Installed AceWin apps") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (apps.isEmpty()) Text("No installed launcher app with the exact label AceWin was found. Install AceWin first.")
                        apps.forEach { (pkg, label) ->
                            OutlinedButton(onClick = { AppPrefs.targetPackage = pkg; target = pkg; showApps = false }) {
                                Text("$label — $pkg")
                            }
                        }
                    }
                },
                confirmButton = { Button(onClick = { showApps = false }) { Text("Close") } }
            )
        }
    }
}
