package com.example.hourlyspinkings

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat

class AutomationRunnerService : Service() {
    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannel(this)
        startForeground(1002, Notifications.foreground(this, "Preparing automation"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Thread {
            try {
                val target = AppPrefs.targetPackage
                if (target.isNullOrBlank()) {
                    fail("No AceWin app selected")
                    return@Thread
                }

                if (SpinAccessibilityService.isUserBusyWithOtherApp(target)) {
                    AppPrefs.state = "WAITING"
                    AppPrefs.lastStatus = "Delayed because another app appears to be in use"
                    LogStore.add("user busy: delayed")
                    AppPrefs.sessionId = null
                    AppPrefs.pendingMode = null
                    Scheduler.scheduleAfter(this, 5 * 60_000L)
                    return@Thread
                }

                AppPrefs.state = "OPENING_ACEWIN"
                LogStore.add("AceWin launch requested")
                wakeBrieflyIfNeeded()
                val launch = packageManager.getLaunchIntentForPackage(target)
                if (launch == null) {
                    fail("Selected AceWin app has no launch intent")
                    return@Thread
                }
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                startActivity(launch)
                LogStore.add("AceWin launched")

                // The AccessibilityService performs the UI state machine.
                stopSelf()
            } catch (e: Exception) {
                fail("Launch failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun wakeBrieflyIfNeeded() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) {
            @Suppress("DEPRECATION")
            val wl = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "HourlySpinKings:ShortWake"
            )
            wl.acquire(8_000L)
            if (wl.isHeld) wl.release()
        }
    }

    private fun fail(reason: String) {
        AppPrefs.state = "ERROR"
        AppPrefs.lastError = reason
        AppPrefs.lastStatus = "Failed: $reason"
        LogStore.add("error: $reason")
        Notifications.show(this, "Hourly Spin Kings", reason)
        AppPrefs.sessionId = null
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
