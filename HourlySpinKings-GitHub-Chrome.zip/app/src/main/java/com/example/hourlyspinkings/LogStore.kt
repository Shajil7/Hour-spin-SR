package com.example.hourlyspinkings

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LogStore {
    private const val FILE = "event_log"
    private const val KEY = "entries"
    private lateinit var context: Context

    fun init(c: Context) { context = c.applicationContext }

    fun add(message: String) {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val old = prefs.getString(KEY, "") ?: ""
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val lines = ("$stamp — $message\n$old").lineSequence().take(200).joinToString("\n")
        prefs.edit().putString(KEY, lines).apply()
    }

    fun all(): String = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
}
