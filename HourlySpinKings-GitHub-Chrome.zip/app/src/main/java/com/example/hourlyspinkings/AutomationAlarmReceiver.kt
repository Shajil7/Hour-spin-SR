package com.example.hourlyspinkings

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.util.UUID

class AutomationAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!AppPrefs.enabled) return
        if (AppPrefs.sessionId != null) return
        AppPrefs.pendingMode = "AUTO"
        AppPrefs.sessionId = UUID.randomUUID().toString()
        AppPrefs.cycleStarted = System.currentTimeMillis()
        AppPrefs.state = "WAKE_REQUESTED"
        LogStore.add("scheduled: alarm fired")
        Notifications.show(context, "Hourly Spin Kings", "Scheduled automation is starting if Android/user state permits.")
        ContextCompat.startForegroundService(context, Intent(context, AutomationRunnerService::class.java))
    }
}
