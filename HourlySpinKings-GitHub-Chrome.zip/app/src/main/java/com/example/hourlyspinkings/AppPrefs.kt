package com.example.hourlyspinkings

import android.content.Context

object AppPrefs {
    private const val FILE = "hourly_spin_kings"
    private const val KEY_TARGET = "target_package"
    private const val KEY_ENABLED = "automation_enabled"
    private const val KEY_TEST_INTERVAL = "test_interval_min"
    private const val KEY_REAL_INTERVAL = "real_interval_min"
    private const val KEY_INITIAL_DELAY = "initial_delay_min"
    private const val KEY_PENDING = "pending_mode"
    private const val KEY_STATE = "state"
    private const val KEY_LAST_STATUS = "last_status"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEY_NEXT_RUN = "next_run"
    private const val KEY_TEST_LOGOUT = "test_logout"
    private const val KEY_CYCLE_STARTED = "cycle_started"
    private const val KEY_SESSION = "session_id"

    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    var targetPackage: String?
        get() = AppContext.get().let { p(it).getString(KEY_TARGET, null) }
        set(v) = AppContext.get().let { p(it).edit().putString(KEY_TARGET, v).apply() }

    var enabled: Boolean
        get() = p(AppContext.get()).getBoolean(KEY_ENABLED, false)
        set(v) = p(AppContext.get()).edit().putBoolean(KEY_ENABLED, v).apply()

    var testIntervalMinutes: Int
        get() = p(AppContext.get()).getInt(KEY_TEST_INTERVAL, 1)
        set(v) = p(AppContext.get()).edit().putInt(KEY_TEST_INTERVAL, v.coerceAtLeast(1)).apply()

    var realIntervalMinutes: Int
        get() = p(AppContext.get()).getInt(KEY_REAL_INTERVAL, 65)
        set(v) = p(AppContext.get()).edit().putInt(KEY_REAL_INTERVAL, v.coerceAtLeast(1)).apply()

    var initialDelayMinutes: Int
        get() = p(AppContext.get()).getInt(KEY_INITIAL_DELAY, 1)
        set(v) = p(AppContext.get()).edit().putInt(KEY_INITIAL_DELAY, v.coerceAtLeast(0)).apply()

    var pendingMode: String?
        get() = p(AppContext.get()).getString(KEY_PENDING, null)
        set(v) = p(AppContext.get()).edit().putString(KEY_PENDING, v).apply()

    var state: String
        get() = p(AppContext.get()).getString(KEY_STATE, "IDLE") ?: "IDLE"
        set(v) = p(AppContext.get()).edit().putString(KEY_STATE, v).apply()

    var lastStatus: String
        get() = p(AppContext.get()).getString(KEY_LAST_STATUS, "Never run") ?: "Never run"
        set(v) = p(AppContext.get()).edit().putString(KEY_LAST_STATUS, v).apply()

    var lastError: String
        get() = p(AppContext.get()).getString(KEY_LAST_ERROR, "") ?: ""
        set(v) = p(AppContext.get()).edit().putString(KEY_LAST_ERROR, v).apply()

    var nextRun: Long
        get() = p(AppContext.get()).getLong(KEY_NEXT_RUN, 0L)
        set(v) = p(AppContext.get()).edit().putLong(KEY_NEXT_RUN, v).apply()

    var testLogout: Boolean
        get() = p(AppContext.get()).getBoolean(KEY_TEST_LOGOUT, false)
        set(v) = p(AppContext.get()).edit().putBoolean(KEY_TEST_LOGOUT, v).apply()

    var cycleStarted: Long
        get() = p(AppContext.get()).getLong(KEY_CYCLE_STARTED, 0L)
        set(v) = p(AppContext.get()).edit().putLong(KEY_CYCLE_STARTED, v).apply()

    var sessionId: String?
        get() = p(AppContext.get()).getString(KEY_SESSION, null)
        set(v) = p(AppContext.get()).edit().putString(KEY_SESSION, v).apply()
}

object AppContext {
    private lateinit var app: Context
    fun init(context: Context) { app = context.applicationContext }
    fun get(): Context = app
}
