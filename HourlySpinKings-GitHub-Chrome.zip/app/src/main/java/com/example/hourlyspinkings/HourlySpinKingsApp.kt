package com.example.hourlyspinkings

import android.app.Application

class HourlySpinKingsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContext.init(this)
        LogStore.init(this)
    }
}
