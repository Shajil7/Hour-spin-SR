package com.example.hourlyspinkings

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!AppPrefs.enabled || AppPrefs.targetPackage.isNullOrBlank()) return
        LogStore.add("boot: restoring scheduler")
        try {
            Scheduler.scheduleAfter(context, AppPrefs.initialDelayMinutes * 60_000L)
        } catch (e: Exception) {
            AppPrefs.lastError = "Boot schedule failed: ${e.message}"
            Notifications.show(context, "Hourly Spin Kings", "Could not restore the schedule. Check Exact Alarms permission.")
        }
    }
}
