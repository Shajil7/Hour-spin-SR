package com.example.hourlyspinkings

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class SpinAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var stepStartedAt = 0L
    private var running = false
    private var state = "IDLE"
    private var session: String? = null
    private var spinWaitUntil = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_CLICKED
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        LogStore.add("Accessibility Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val target = AppPrefs.targetPackage ?: return
        val pending = AppPrefs.pendingMode ?: return
        val currentSession = AppPrefs.sessionId
        if (currentSession == null || pending.isBlank()) return

        val pkg = event?.packageName?.toString()
        if (pkg != null && pkg != target) return
        if (!running) startSession(currentSession, pending)
    }

    override fun onInterrupt() {
        LogStore.add("Accessibility Service interrupted")
        stopSession("Accessibility interrupted")
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun startSession(id: String, mode: String) {
        if (running) return
        running = true
        session = id
        state = "DISMISS_POPUPS"
        AppPrefs.state = state
        stepStartedAt = System.currentTimeMillis()
        LogStore.add("session started ($mode)")
        tick(mode)
    }

    private fun tick(mode: String) {
        if (!running || session != AppPrefs.sessionId) return
        val target = AppPrefs.targetPackage ?: return stopSession("No target app selected")
        val now = System.currentTimeMillis()
        if (now - stepStartedAt > timeoutFor(state)) {
            stopSession("Timeout in $state")
            return
        }

        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()
        if (pkg != null && pkg != target) {
            handler.postDelayed({ tick(mode) }, 700)
            return
        }

        when (state) {
            "DISMISS_POPUPS" -> {
                if (dismissSafePopup(root)) {
                    stepStartedAt = now
                    handler.postDelayed({ tick(mode) }, 900)
                } else {
                    setState("HOME")
                    handler.postDelayed({ tick(mode) }, 500)
                }
            }
            "HOME" -> {
                if (clickExact(root, "Home")) {
                    LogStore.add("Home found")
                    handler.postDelayed({ tick(mode) }, 800)
                }
                if (clickExact(root, "Hourly Spin")) {
                    LogStore.add("Hourly Spin found")
                    setState("OPEN_HOURLY_SPIN")
                    handler.postDelayed({ tick(mode) }, 900)
                } else {
                    handler.postDelayed({ tick(mode) }, 600)
                }
            }
            "OPEN_HOURLY_SPIN" -> {
                if (findExact(root, "Tap to Spin") != null) {
                    setState("TAP_TO_SPIN")
                    handler.postDelayed({ tick(mode) }, 300)
                } else {
                    handler.postDelayed({ tick(mode) }, 700)
                }
            }
            "TAP_TO_SPIN" -> {
                val node = findExact(root, "Tap to Spin")
                if (node != null && isSafeClickable(node)) {
                    if (now - lastActionAt < 1500) {
                        handler.postDelayed({ tick(mode) }, 600)
                    } else {
                        if (clickNode(node)) {
                            lastActionAt = now
                            spinWaitUntil = now + 2500
                            LogStore.add("Tap to Spin clicked once")
                            setState("WAIT_FOR_RESULT")
                            handler.postDelayed({ tick(mode) }, 900)
                        } else stopSession("Could not click Tap to Spin")
                    }
                } else {
                    handler.postDelayed({ tick(mode) }, 600)
                }
            }
            "WAIT_FOR_RESULT" -> {
                if (now < spinWaitUntil) {
                    handler.postDelayed({ tick(mode) }, 700)
                } else {
                    LogStore.add("spin wait completed")
                    setState("RETURN_HOME")
                    handler.postDelayed({ tick(mode) }, 300)
                }
            }
            "RETURN_HOME" -> {
                // Prefer Android Back exactly once after the spin page.
                performGlobalAction(GLOBAL_ACTION_BACK)
                LogStore.add("Back pressed once")
                setState("OPEN_PROFILE")
                handler.postDelayed({ tick(mode) }, 1000)
            }
            "OPEN_PROFILE" -> {
                if (clickExact(root, "Profile")) {
                    LogStore.add("Profile opened")
                    if (mode == "TEST" && !AppPrefs.testLogout) {
                        completeCycle("Test completed before logout")
                    } else {
                        setState("LOGOUT_STEP")
                        handler.postDelayed({ tick(mode) }, 900)
                    }
                } else {
                    handler.postDelayed({ tick(mode) }, 600)
                }
            }
            "LOGOUT_STEP" -> {
                val logout = findExact(root, "Log out")
                if (logout != null && isSafeClickable(logout)) {
                    if (clickNode(logout)) {
                        LogStore.add("Log out clicked; confirmation will not be auto-confirmed")
                        setState("ERROR")
                        AppPrefs.lastError = "Logout confirmation, if shown, was intentionally not confirmed."
                        completeCycle("Stopped at logout confirmation boundary")
                    } else stopSession("Could not click Log out")
                } else {
                    if (scrollForwardOnce(root)) {
                        LogStore.add("scrolled Profile screen")
                    }
                    handler.postDelayed({ tick(mode) }, 900)
                }
            }
            "ERROR" -> stopSession("Stopped")
            else -> handler.postDelayed({ tick(mode) }, 600)
        }
    }

    private fun completeCycle(status: String) {
        val started = AppPrefs.cycleStarted
        val elapsed = if (started > 0) System.currentTimeMillis() - started else 0L
        AppPrefs.lastStatus = status
        AppPrefs.lastError = if (status.contains("Stopped")) AppPrefs.lastError else ""
        LogStore.add("cycle completed: $status (${elapsed / 1000}s)")

        val mode = AppPrefs.pendingMode
        running = false
        state = "CYCLE_COMPLETE"
        AppPrefs.state = state
        AppPrefs.pendingMode = null
        AppPrefs.sessionId = null

        if (mode == "AUTO" && AppPrefs.enabled) {
            try {
                // The 65-minute interval is measured from cycle start, per the requested behavior.
                val target = AppPrefs.cycleStarted + AppPrefs.realIntervalMinutes * 60_000L
                val next = maxOf(System.currentTimeMillis() + 5_000L, target)
                Scheduler.scheduleAt(this, next)
                LogStore.add("next cycle scheduled")
            } catch (e: Exception) {
                AppPrefs.state = "ERROR"
                AppPrefs.lastError = "Could not schedule next cycle: ${e.message}"
                Notifications.show(this, "Hourly Spin Kings", "Next cycle could not be scheduled. Check Exact Alarms permission.")
            }
        }
        Notifications.show(this, "Hourly Spin Kings", status)
        handler.removeCallbacksAndMessages(null)
    }

    private fun stopSession(reason: String) {
        if (!running) return
        running = false
        AppPrefs.state = "ERROR"
        AppPrefs.lastError = reason
        AppPrefs.lastStatus = "Failed: $reason"
        LogStore.add("error/stop: $reason")
        Notifications.show(this, "Hourly Spin Kings", reason)
        AppPrefs.pendingMode = null
        AppPrefs.sessionId = null
        handler.removeCallbacksAndMessages(null)
    }

    private fun setState(newState: String) {
        state = newState
        AppPrefs.state = newState
        stepStartedAt = System.currentTimeMillis()
    }

    private fun timeoutFor(s: String): Long = when (s) {
        "DISMISS_POPUPS", "HOME", "OPEN_HOURLY_SPIN", "OPEN_PROFILE", "LOGOUT_STEP" -> 25_000L
        "TAP_TO_SPIN", "WAIT_FOR_RESULT", "RETURN_HOME" -> 20_000L
        else -> 30_000L
    }

    private fun dismissSafePopup(root: AccessibilityNodeInfo?): Boolean {
        if (root == null) return false
        val hasPasswordWarning = containsText(root, "Check passwords") || containsText(root, "Google Password Manager")
        val hasPromoDetails = containsText(root, "Details")
        val close = findExact(root, "Close") ?: findContentDescription(root, "Close") ?: findContentDescription(root, "Dismiss")
        if (close != null && isSafeClickable(close) && (hasPasswordWarning || hasPromoDetails)) {
            if (clickNode(close)) {
                LogStore.add("popup dismissed safely")
                return true
            }
        }
        return false
    }

    private fun clickExact(root: AccessibilityNodeInfo?, text: String): Boolean {
        val node = findExact(root, text) ?: return false
        return isSafeClickable(node) && clickNode(node)
    }

    private fun isSafeClickable(node: AccessibilityNodeInfo): Boolean {
        if (!node.isVisibleToUser) return false
        if (node.isClickable) return true
        var p = node.parent
        var depth = 0
        while (p != null && depth++ < 4) {
            if (p.isVisibleToUser && p.isClickable) return true
            p = p.parent
        }
        return false
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        if (!node.isVisibleToUser) return false
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var p = node.parent
        var depth = 0
        while (p != null && depth++ < 4) {
            if (p.isVisibleToUser && p.isClickable) return p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            p = p.parent
        }
        return false
    }

    private fun findExact(root: AccessibilityNodeInfo?, wanted: String): AccessibilityNodeInfo? {
        if (root == null) return null
        val target = normalize(wanted)
        val text = normalize(root.text?.toString())
        if (text == target && root.isVisibleToUser) return root
        for (i in 0 until root.childCount) {
            val result = findExact(root.getChild(i), wanted)
            if (result != null) return result
        }
        return null
    }

    private fun findContentDescription(root: AccessibilityNodeInfo?, wanted: String): AccessibilityNodeInfo? {
        if (root == null) return null
        if (normalize(root.contentDescription?.toString()) == normalize(wanted) && root.isVisibleToUser) return root
        for (i in 0 until root.childCount) {
            val result = findContentDescription(root.getChild(i), wanted)
            if (result != null) return result
        }
        return null
    }

    private fun scrollForwardOnce(root: AccessibilityNodeInfo?): Boolean {
        if (root == null) return false
        if (root.isVisibleToUser && root.isScrollable) {
            return root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        }
        for (i in 0 until root.childCount) {
            if (scrollForwardOnce(root.getChild(i))) return true
        }
        return false
    }

    private fun containsText(root: AccessibilityNodeInfo?, wanted: String): Boolean {
        if (root == null) return false
        if (normalize(root.text?.toString()).contains(normalize(wanted))) return true
        for (i in 0 until root.childCount) if (containsText(root.getChild(i), wanted)) return true
        return false
    }

    private fun normalize(s: String?): String = s?.trim()?.replace(Regex("\\s+"), " ")?.lowercase(Locale.getDefault()) ?: ""

    companion object {
        @Volatile private var instance: SpinAccessibilityService? = null

        fun isUserBusyWithOtherApp(targetPackage: String): Boolean {
            val service = instance ?: return false
            val pm = service.getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (!pm.isInteractive) return false
            val pkg = service.rootInActiveWindow?.packageName?.toString() ?: return false
            val own = service.packageName
            if (pkg == targetPackage || pkg == own) return false
            val homePackages = service.packageManager.queryIntentActivities(
                android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME), 0
            ).map { it.activityInfo.packageName }
            return pkg !in homePackages
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
