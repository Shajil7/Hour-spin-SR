@echo off
REM Android Studio can regenerate this wrapper if the wrapper JAR is absent.
gradle %*
